import 'package:flutter/material.dart';

// استدعاء الصفحات الأخرى
import 'screens/stop_habit.dart';
import 'screens/programming.dart';
import 'screens/cybersecurity.dart';
import 'screens/trading.dart';
import 'screens/fitness.dart';
import 'screens/nutrition.dart';

void main() {
  runApp(HayatiJadida());
}

class HayatiJadida extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حياتي الجديدة',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatelessWidget {
  final sections = [
    {"title": "التوقف عن العادة السرية", "screen": StopHabitScreen()},
    {"title": "تعلم البرمجة", "screen": ProgrammingScreen()},
    {"title": "الأمن السيبراني", "screen": CyberSecurityScreen()},
    {"title": "التداول", "screen": TradingScreen()},
    {"title": "الرياضة", "screen": FitnessScreen()},
    {"title": "التغذية", "screen": NutritionScreen()},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('حياتي الجديدة')),
      body: ListView.builder(
        itemCount: sections.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(
                sections[index]["title"] as String,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          sections[index]["screen"] as Widget),
                );
              },
            ),
          );
        },
      ),
    );
  }
}