import 'package:flutter/material.dart';

class TradingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('التداول')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            Text("أنواع التداول:",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              "1. الفوركس.\n"
              "2. الأسهم.\n"
              "3. العملات الرقمية.\n"
              "4. إدارة المخاطر.",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}