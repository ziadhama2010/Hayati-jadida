import 'package:flutter/material.dart';

class FitnessScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الرياضة')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            Text("برنامج رياضي:",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              "1. تمارين Calisthenics (Push-ups, Pull-ups).\n"
              "2. رفع الأثقال تدريجياً.\n"
              "3. الالتزام بـ3 إلى 5 حصص في الأسبوع.",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}