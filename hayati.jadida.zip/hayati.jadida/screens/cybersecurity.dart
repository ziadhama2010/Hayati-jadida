import 'package:flutter/material.dart';

class CyberSecurityScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الأمن السيبراني')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            Text("خطة تعلم الأمن السيبراني:",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              "1. الأساسيات: الشبكات، التشفير.\n"
              "2. أدوات الدفاع: Wireshark.\n"
              "3. الهجوم الأخلاقي: Kali Linux.\n"
              "4. التدريب على CTF.",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}