import 'package:flutter/material.dart';

class ProgrammingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تعلم البرمجة')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            Text("خطوات تعلم البرمجة:",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              "1. تعلم HTML وCSS.\n"
              "2. تعلم Python.\n"
              "3. مشاريع صغيرة.\n"
              "4. منصات مجانية مثل FreeCodeCamp.",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}