import 'package:flutter/material.dart';

class NutritionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('التغذية')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            Text("خطة تغذية اقتصادية:",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              "1. ميزانية 20 درهم/اليوم.\n"
              "2. بروتين: بيض، عدس، حمص.\n"
              "3. خضر وفواكه موسمية.\n"
              "4. شرب الماء بكثرة.",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}