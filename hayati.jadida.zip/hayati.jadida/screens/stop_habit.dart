import 'package:flutter/material.dart';

class StopHabitScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('التوقف عن العادة السرية')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            Text("خطة التوقف عن العادة السرية:",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Text(
              "1. تحديد هدف واضح.\n"
              "2. ملء الوقت بالأنشطة المفيدة.\n"
              "3. تلاوة القرآن والأذكار.\n"
              "4. ممارسة الرياضة يومياً.",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}